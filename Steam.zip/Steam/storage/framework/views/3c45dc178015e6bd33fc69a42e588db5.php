

<?php $__env->startSection('titre','accueil | index'); ?>

<?php $__env->startSection('contenu'); ?>

  <!-- ***** Preloader Start ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->



  <div class="section most-played">
    <div class="container">
      <h1 class="text-center mb-3">Liste des usagers</h1>
     <a href="/usagers/create"> <button style="--clr:#B72727 " class="lebtn mb-4" ><span> Ajouter un usager</span><i></i></button></a>
        <div class="row">
            <?php if(count($usagers)): ?>
              <?php $__currentLoopData = $usagers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
      <div class="col-lg-2 col-md-6 align-self-center mb-3 trending-items col-md-6 adv">
        <div class="item">
          <div class="thumb">
            <a href=""><img src="<?php echo e(asset('assets/images/use.png')); ?>" alt="" ></a>
          
          </div>
          <div class="down-content">
            <span class="category"><?php echo e($usager->statut); ?></span>
            <h4><?php echo e($usager->prenom); ?>  <?php echo e($usager->nom); ?></h4>
            <a href=""><i class="fa-solid fa-magnifying-glass"></i></a>
            <a href=""><i class="fa-solid fa-pen-nib"></i></a>
            <ul>
              <li><?php echo e($usager->nbPubli); ?>  jeu(x) publiés</li>
              <li><?php echo e($usager->courriel); ?></li>
              
            </ul>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
    <?php endif; ?> 
    </div>
<hr>
    <div class="row">
      <?php if(count($groupes)): ?>
        <?php $__currentLoopData = $groupes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
<div class="col-lg-2 col-md-6 align-self-center mb-3 trending-items col-md-6 adv">
  <div class="item">
    <div class="thumb">
      <a href=""><img src="<?php echo e(asset('assets/images/team.png')); ?>" alt=""  ></a>
    
    </div>
    <div class="down-content">
      <span class="category"> Cours: <?php echo e($groupe->nomCours); ?> </span>
      <h4><span id="span"><?php echo e($groupe->nbEtud); ?> </span>étudiants</h4>
      <a href=""><i class="fa-solid fa-pen-nib"></i></a>

      </ul>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
<?php endif; ?> 
</div>

<hr>
    <div class="row">
      <?php if(count($equipes)): ?>
        <?php $__currentLoopData = $equipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
<div class="col-lg-2 col-md-6 align-self-center mb-3 trending-items col-md-6 adv">
  <div class="item">
    <div class="thumb">
      <a href=""><img src="<?php echo e(asset('assets/images/team.png')); ?>" alt="" ></a>
    
    </div>
    <div class="down-content">
      <span class="category"><?php echo e($equipe->nbMembres); ?> membre(s)</span>
      <h4>Équipe numéro <span id="span"><?php echo e($equipe->numEquipe); ?></span></h4>
      <a href=""><i class="fa-solid fa-pen-nib"></i></a>

      </ul>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
<?php endif; ?> 
</div>
  </div>
  </div>
  <style>
    html,body{
        background-color: #0071f8;
    }

    #span{
      color: #e91506
    }
.lebtn {
  position: relative;
  background: #444;
  color: #00a6e7;
  text-decoration: none;
  text-transform: uppercase;
  border: none;
  letter-spacing: 0.1rem;
  font-size: 1rem;
  padding: 1rem 3rem;
  transition: 0.2s;
}

.lebtn:hover {
  letter-spacing: 0.2rem;
  padding: 1.1rem 3.1rem;
  background: var(--clr);
  color: var(--clr);
  /* box-shadow: 0 0 35px var(--clr); */
  animation: box 3s infinite;
}

.lebtn::before {
  content: "";
  position: absolute;
  inset: 2px;
  background: #272822;
}

.lebtn span {
  position: relative;
  z-index: 1;
}
.lebtn i {
  position: absolute;
  inset: 0;
  display: block;
}

.lebtn i::before {
  content: "";
  position: absolute;
  width: 10px;
  height: 2px;
  left: 80%;
  top: -2px;
  border: 2px solid var(--clr);
  background: #272822;
  transition: 0.2s;
}

.lebtn:hover i::before {
  width: 15px;
  left: 20%;
  animation: move 3s infinite;
}

.lebtn i::after {
  content: "";
  position: absolute;
  width: 10px;
  height: 2px;
  left: 20%;
  bottom: -2px;
  border: 2px solid var(--clr);
  background: #272822;
  transition: 0.2s;
}

.lebtn:hover i::after {
  width: 15px;
  left: 80%;
  animation: move 3s infinite;
}

@keyframes move {
  0% {
    transform: translateX(0);
  }
  50% {
    transform: translateX(5px);
  }
  100% {
    transform: translateX(0);
  }
}

@keyframes box {
  0% {
    box-shadow: #27272c;
  }
  50% {
    box-shadow: 0 0 25px var(--clr);
  }
  100% {
    box-shadow: #27272c;
  }
}


</style>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\steam\Steam\resources\views/usagers/index.blade.php ENDPATH**/ ?>