

<?php $__env->startSection('titre','details | index'); ?>

<?php $__env->startSection('contenu'); ?>

<?php if(isset($jeu)): ?>



  <div class="page-heading header-text">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <h3><?php echo e($jeu->titre); ?></h3>
          <span class="breadcrumb"><a href="/accueil">Maison</a>  >  <a href="/jeux">Jeux</a>> <?php echo e($jeu->titre); ?></span>
        </div>
      </div>
    </div>
  </div>




  <div class="single-product section">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="left-image">
         
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleControls" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleControls" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleControls" data-bs-slide-to="2" aria-label="Slide 3"></button>
              </div>
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="<?php echo e($jeu->cover); ?>" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="<?php echo e($jeu->media->im2); ?>" class="d-block w-100" alt="<?php echo e($jeu->titre); ?>">
                </div>
                <div class="carousel-item">
                  <img src="<?php echo e($jeu->media->im3); ?>" class="d-block w-100" alt="...">
                </div>
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
        
          </div>
        </div>
        <div class="col-lg-6 align-self-center">
          <h4><?php echo e($jeu->titre); ?></h4>
          <span class="price"><?php echo e($jeu->nbTelech); ?> Telechargements</span>
          <p><?php echo e($jeu->description); ?></p>
          <form id="qty" action="#">
            
 
            <button type="submit"><i class="fa fa-shopping-bag"></i> Telecharger</button>
          </form>
          <ul>
            <li>
              <span>Créateur(s):</span>
              <?php $__currentLoopData = $jeu->equipe->usagers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $usager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($usager->nom); ?><?php if(!$loop->last): ?>, <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </li>
          
            <li><span>Categorie:</span> <?php echo e($jeu->categorie->nom); ?></li>
            <li><span>Multi-tags:</span><?php echo e($jeu->tags); ?></li>
            <li><span>Platforms:</span><?php echo e($jeu->platforms); ?></li>
          </ul>
        </div>
        <div class="col-lg-12">
          <div class="sep"></div>
        </div>
      </div>
    </div>
  </div>

  <div class="more-info">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="tabs-content">
            <div class="row">
              <div class="nav-wrapper ">
                <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="description-tab" data-bs-toggle="tab" data-bs-target="#description" type="button" role="tab" aria-controls="description" aria-selected="true">Description</button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link" id="reviews-tab" data-bs-toggle="tab" data-bs-target="#reviews" type="button" role="tab" aria-controls="reviews" aria-selected="false">Revues (<?php echo e(count($jeu->revues)); ?>)</button>
                  </li>
                </ul>
              </div>            
       
              <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-tab">
                  <p><?php echo e($jeu->description); ?></p>
                </div>
                <div class="tab-pane fade" id="reviews" role="tabpanel" aria-labelledby="reviews-tab"> 
                  <form action="" class="col-5 m-3" action="<?php echo e(route('revues')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <textarea class="form-control m-3" placeholder="Entrez votre commentaire" name="avis"></textarea>
                    <input type="text" class="form-control mx-3" name="note" placeholder="votre note (/5)">
                    <input type="hidden" name="jeu_id" value="<?php echo e($jeu->id); ?>">
                    <button type="submit" class="btn btn-primary m-3">Ajouter</button>
                  </form>
                  <?php $__currentLoopData = $jeu->revues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="row">
                    <hr>
                    <div class="col-1">
                      <img src="<?php echo e(asset('assets/images/user.png')); ?>"  alt="user" class="img-fluid">
                    </div>
                    <div class="col-11">  <p class="">(<?php echo e($revue->note); ?>) <?php echo e($revue->avis); ?> </p> <br></div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="section categories related-games">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="section-heading">
            <h6>Action</h6>
            <h2>Jeux similaires</h2>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="main-button">
            <a href="shop.html">View All</a>
          </div>
        </div>
        <?php $__currentLoopData = $jeu->categorie->jeux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lejeu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($lejeu->nom == $jeu->nom): ?>
            <div class="col-lg-2 col-md-6 col-sm-6">
              <div class="item">
                <div class="thumb">
                  <a href="<?php echo e(route('jeux.show',[$lejeu])); ?>"><img src="<?php echo e(asset('assets/imgJeux/'. $lejeu->cover)); ?>" alt="" height="120"></a>
                </div>
                <div class="down-content">
                    <span class="category"><?php echo e($lejeu->type); ?></span>
                    <h4><?php echo e($lejeu->titre); ?></h4>
                    <a href="<?php echo e(route('jeux.show',[$lejeu])); ?>">Explorer</a>
                </div>
              </div>
            </div>

            
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
    </div>
  </div>
  <style>

  </style>
  <?php else: ?> 
  <p>FAULEIN</p>

  

  <?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\steam\Steam\resources\views/jeux/show.blade.php ENDPATH**/ ?>