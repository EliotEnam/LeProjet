

<?php $__env->startSection('titre','accueil | index'); ?>

<?php $__env->startSection('contenu'); ?>

<div class="section trending py-5 bg-light">
    <div class="container">
        <div class="card shadow-lg">
            <div class="card-body">
                <h1 class="text-center text-danger mb-4">Ajouter un usager</h1>
                <form method="POST" action="<?php echo e(route('usagers.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Matricule</label>
                        <input type="text" class="form-control" name="matricule" required value="<?php echo e(old('matricule')); ?>" placeholder="Entrez le matricule">
                        <?php $__currentLoopData = $errors->get('matricule'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger mt-2">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                     
                    <div class="mb-3">
                        <label class="form-label fw-bold">Mot de passe</label>
                        <input type="text" class="form-control" name="password" required value="<?php echo e(old('password')); ?>" placeholder="Entrez le mot de passe">
                        <?php $__currentLoopData = $errors->get('password'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger mt-2">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
     
                    <div class="mb-3">
                        <label class="form-label fw-bold">Équipe(facultatif)</label>
                        <select name="equipe_id" id="equipe_id" class="form-control">
                            <option value="" disabled selected>Choisissez une équipe</option>
                            <?php $__currentLoopData = $equipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($equipe->id); ?>"><?php echo e($equipe->numEquipe); ?> <?php $__currentLoopData = $equipe->usagers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $usager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    (<?php echo e($usager->nom); ?>)<?php if(!$loop->last): ?>, <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__currentLoopData = $errors->get('equipe_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nom</label>
                        <input type="text" class="form-control" name="nom" required value="<?php echo e(old('nom')); ?>" placeholder="Entrez un nom">
                        <?php $__currentLoopData = $errors->get('nom'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

             
                    <div class="mb-3">
                        <label class="form-label fw-bold">Prénom</label>
                        <input type="text" class="form-control" name="prenom" required value="<?php echo e(old('prenom')); ?>" placeholder="Entrez un prénom">
                        <?php $__currentLoopData = $errors->get('prenom'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
               
                    <div class="mb-3">
                        <label class="form-label fw-bold">Courriel</label>
                        <input type="text" class="form-control" name="courriel" required value="<?php echo e(old('courriel')); ?>" placeholder="Entrez une adresse courriel">
                        <?php $__currentLoopData = $errors->get('courriel'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>


                    <div class="mb-3">
                        <label class="form-label fw-bold">Courriel</label>
                        <select class="form-select" aria-label="Default select example" name="statut">
                            <option selected>Sélectionnez le rôle de l'usager</option>
                            <option value="professeur">Professeur</option>
                            <option value="etudiant">Étudiant</option>
                            <option value="etudiantInfo">ÉtudiantInfo</option>
                          </select>
                        <?php $__currentLoopData = $errors->get('statut'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
            
                    <input type="hidden" name="nbPubli" value="0">

                    <!-- Submit Button -->
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary px-5 py-2">Ajouter le Jeu</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<style>
    html,body{
        background-color: #0071f8;
    }

</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\steam\Steam\resources\views/usagers/create.blade.php ENDPATH**/ ?>