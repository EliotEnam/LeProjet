

<?php $__env->startSection('titre','Modification | index'); ?>

<?php $__env->startSection('contenu'); ?>

<div class="section trending py-5 bg-light">
    <div class="container">
        <div class="card shadow-lg">
            <div class="card-body">
                <h1 class="text-center text-danger mb-4">Modification de <?php echo e($jeu->titre); ?></h1>
                <form method="POST" action="<?php echo e(route('jeux.update',[$jeu])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Titre du jeu</label>
                        <input type="text" class="form-control" name="titre" required value="<?php echo e(old('nom', $jeu->titre)); ?>" placeholder="Entrez le titre du jeu">
                        <?php $__currentLoopData = $errors->get('titre'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger mt-2">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

            
                    <div class="mb-3">
                        <label class="form-label fw-bold">Catégorie de jeu</label>
                        <select name="categorie_id" id="categorie_id" class="form-control">
                            <option value="" disabled selected>Choisissez une catégorie</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->nom); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__currentLoopData = $errors->get('categorie_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                
                    <div class="mb-3">
                        <label class="form-label fw-bold">Équipe réalisatrice</label>
                        <select name="equipe_id" id="equipe_id" class="form-control">
                            <option value="" disabled selected>Choisissez une équipe</option>
                            <?php $__currentLoopData = $equipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($equipe->id); ?>"><?php echo e($equipe->numEquipe); ?> <?php $__currentLoopData = $equipe->usagers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $usager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    (<?php echo e($usager->nom); ?>)<?php if(!$loop->last): ?>, <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__currentLoopData = $errors->get('equipe_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                
                    <div class="mb-3">
                        <label class="form-label fw-bold">Description du jeu</label>
                        <textarea name="description" id="description" class="form-control" placeholder="Entrez une description" rows="4" required ><?php echo e(old('nom', $jeu->description)); ?></textarea>
                        <?php $__currentLoopData = $errors->get('description'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

             
                    <div class="mb-3">
                        <label class="form-label fw-bold">Tags</label>
                        <input type="text" class="form-control" name="tags" required value="<?php echo e(old('nom', $jeu->tags)); ?>" placeholder="Ex: action, aventure, stratégie">
                        <?php $__currentLoopData = $errors->get('tags'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                
                    <div class="mb-3">
                        <label class="form-label fw-bold">Année de sortie</label>
                        <input type="number" class="form-control" name="annee" required value="<?php echo e(old('nom', $jeu->annee)); ?>" placeholder="Ex: 2024">
                        <?php $__currentLoopData = $errors->get('annee'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

               
                    <div class="mb-3">
                        <label class="form-label fw-bold">Plateformes</label>
                        <input type="text" class="form-control" name="platforms" required value="<?php echo e(old('nom', $jeu->platforms)); ?>" placeholder="Ex: PC, PS5, Xbox Series">
                        <?php $__currentLoopData = $errors->get('platforms'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

               
                    <div class="mb-3">
                        <label class="form-label fw-bold">Image de couverture</label>
                        <input type="url" class="form-control" name="cover" required value="<?php echo e(old('nom', $jeu->cover)); ?>" placeholder="URL de l'image de couverture">
                        <?php $__currentLoopData = $errors->get('cover'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Image 2</label>
                        <input type="url" class="form-control" name="im2" required value="<?php echo e(old('nom', $jeu->media->im2)); ?>" placeholder="URL de l'image supplémentaire">
                        <?php $__currentLoopData = $errors->get('im2'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Image 3</label>
                        <input type="url" class="form-control" name="im3" required value="<?php echo e(old('nom', $jeu->media->im3)); ?>" placeholder="URL de l'image supplémentaire">
                        <?php $__currentLoopData = $errors->get('im3'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

            
                    <input type="hidden" name="nbTelech" value="0">
                    <input type="hidden" name="note" value="0">

                    <!-- Submit Button -->
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary px-5 py-2">Modifier</button>
                    </div>

                    
                   

                </form>
            </div>
        </div>
    </div>
</div>

<form method="POST" action="<?php echo e(route('jeux.destroy', [$jeu->id])); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="btn btn-danger">Supprimer</button>
    </form>
<style>
    html,body{
        background-color: #0071f8;
    }

</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\steam\Steam\resources\views/jeux/modifier.blade.php ENDPATH**/ ?>