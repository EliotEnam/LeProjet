

<?php $__env->startSection('titre','mes jeux'); ?>

<?php $__env->startSection('contenu'); ?>


<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('errors') && $errors->any()): ?>
<div class="alert alert-danger">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p><?php echo e($error); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

  <div class="page-heading header-text">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <h3>Mes jeux</h3>
          <span class="breadcrumb"><a href="#">Maison</a> > Mes jeux</span>
        </div>
      </div>
    </div>
  </div>

  <div class="section trending">
    <div class="container">
      <ul class="trending-filter">
        <li>
          <a class="is_active" href="#!" data-filter="*">Show All</a>
        </li>
        <li>
          <a href="#!" data-filter=".adv">Adventure</a>
        </li>
        <li>
          <a href="#!" data-filter=".str">Strategy</a>
        </li>
        <li>
          <a href="#!" data-filter=".rac">Racing</a>
        </li>
      </ul>
      <div class="row">
              <?php if(count($jeux)): ?>
                <?php $__currentLoopData = $jeux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jeu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
        <div class="col-lg-3 col-md-6 align-self-center mb-30 trending-items col-md-6 adv">
          <div class="item">
            <div class="thumb">
              <a href="<?php echo e(route('jeux.show',[$jeu])); ?>"><img src="<?php echo e(asset('assets/imgJeux/'. $jeu->cover)); ?>" alt="" width="250px" height="220px"></a>
            
            </div>
            <div class="down-content">
              <span class="category"><?php echo e($jeu->categorie->nom); ?></span>
              <h4><?php echo e($jeu->titre); ?></h4>
              <?php if(auth()->guard()->check()): ?>
                   <a href="<?php echo e(route('jeux.edit',[$jeu])); ?>"><i class="fa-solid fa-pen-nib"></i></a>
              <?php endif; ?>
             
              <ul>
                <li><i class="fa fa-star"></i> <?php echo e($jeu->note); ?></li>
                <li><i class="fa fa-download"></i> <?php echo e($jeu->nbTelech); ?></li>
              </ul>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
      <?php endif; ?> 
      </div>
      </div>

     
      <div class="row">
        <div class="col-lg-12">
          <ul class="pagination">
          <li><a href="#"> &lt; </a></li>
            <li><a href="#">1</a></li>
            <li><a class="is_active" href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#"> &gt; </a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
<style>
  .fa-star{
    color: #94370B
  }
  .fa-download{
    color: #113192
  }
  #delete{
    font-size: 20px
  }
</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\steam\Steam\resources\views/jeux/mesJeux.blade.php ENDPATH**/ ?>