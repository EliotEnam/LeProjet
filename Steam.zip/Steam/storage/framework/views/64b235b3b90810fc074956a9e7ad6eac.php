

<?php $__env->startSection('titre','accueil | index'); ?>

<?php $__env->startSection('contenu'); ?>

<div class="section trending py-5 bg-light">
    <div class="container">
        <div class="card shadow-lg">
            <div class="card-body">
                <h1 class="text-center text-danger mb-4">Modifier <?php echo e($usager->nom); ?> <?php echo e($usager->prenom); ?></h1>
              
                <form method="POST" action="<?php echo e(route('usagers.update',[$usager])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Matricule</label>
                        <input type="text" class="form-control" name="matricule" required value="<?php echo e(old('matricule', $usager->matricule)); ?>" placeholder="Entrez le matricule">
                        <?php $__currentLoopData = $errors->get('matricule'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger mt-2">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">
                            <input type="checkbox" id="cachePass" class="form-check-input"> Changer le mot de passe
                        </label>
                    </div>
           
                    <div id="pass" style="display: none;">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Mot de passe</label>
                            <input type="text" class="form-control" name="" value="<?php echo e(old('password')); ?>" placeholder="Entrez le mot de passe" id="lepass">
                            <?php $__currentLoopData = $errors->get('matricule'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger mt-2">
                                    <?php echo e($error); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>  
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nom</label>
                        <input type="text" class="form-control" name="nom" required value="<?php echo e(old('nom', $usager->nom)); ?>" placeholder="Entrez un nom">
                        <?php $__currentLoopData = $errors->get('nom'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

             
                    <div class="mb-3">
                        <label class="form-label fw-bold">Prénom</label>
                        <input type="text" class="form-control" name="prenom" required value="<?php echo e(old('prenom', $usager->prenom)); ?>" placeholder="Entrez un prénom">
                        <?php $__currentLoopData = $errors->get('prenom'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
               
                    <div class="mb-3">
                        <label class="form-label fw-bold">Courriel</label>
                        <input type="text" class="form-control" name="courriel" required value="<?php echo e(old('courriel', $usager->courriel)); ?>" placeholder="Entrez une adresse courriel">
                        <?php $__currentLoopData = $errors->get('courriel'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger mt-2">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>


                    <div class="mb-3">
                        <label class="form-label fw-bold">Statut de l'usager</label>
                        <select class="form-select" aria-label="Default select example" name="statut">
                            <?php if(Auth::check() && Auth::user()->statut == 'professeur'): ?>
                            <option value="professeur" <?php echo e(old('statut', $usager->statut ?? '') == 'professeur' ? 'selected' : ''); ?>>Professeur</option>
                            <?php endif; ?>
                            <option value="etudiant" <?php echo e(old('statut', $usager->statut ?? '') == 'etudiant' ? 'selected' : ''); ?>>Étudiant</option>
                            <option value="etudiantInfo" <?php echo e(old('statut', $usager->statut ?? '') == 'etudiantInfo' ? 'selected' : ''); ?>>ÉtudiantInfo</option>
                        </select>
                        <?php $__currentLoopData = $errors->get('statut'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger mt-2">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    
            
                    <input type="hidden" name="nbPubli" value="<?php echo e($usager->nbPubli); ?>">

                    <!-- Submit Button -->
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary px-5 py-2">Modifier l'usager</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    document.getElementById('cachePass').addEventListener('change', function() {
        const pass = document.getElementById('pass');
        const lepass = document.getElementById('lepass');
        if (this.checked) {
            pass.style.display = 'block';
            lepass.name='password'
            lepass.required = true;
      
   
        } else {
            pass.style.display = 'none';
            lepass.name=''
            lepass.required = false;
        }
    });
</script>
<style>

    html,body{
        background-color: #0071f8;
    }

</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\steam\Steam\resources\views/usagers/modifier.blade.php ENDPATH**/ ?>