@extends('layouts.app')

@section('titre','accueil | index')

@section('contenu')



<h1>Fraulein</h1>

@endsection