@extends('layouts.app')

@section('titre','accueil | index')

@section('contenu')


@endsection